# BRIG - Início - BRIG - Guia de Implementação Brasileiro para IDMP v0.0.3

* [**Table of Contents**](toc.md)
* **BRIG - Início**

## BRIG - Início

| | | |
| :--- | :--- | :--- |
| *Official URL*:https://idmp-br.github.io/brig-idmp-brasil/ImplementationGuide/brig.idmp.brazil | *Version*:0.0.3 | |
| *IG Standards status:*[Draft](http://hl7.org/fhir/R5/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 0 | *Computable Name*:BRIGIDMPBrazil |
| **Copyright/Legal**: Copyright © 2025 Farmaco.io. Este trabalho está licenciado sob a MIT License. FHIR® é marca registrada da HL7 International, usada com permissão. | | |

# BRIG - Brazilian Implementation Guide for IDMP

## Visão Geral

O BRIG (BRazilian Implementation Guide for IDMP) é uma implementação brasileira dos padrões FHIR R5 para Identificação de Produtos Medicinais (IDMP), desenvolvido para harmonizar dados de medicamentos no contexto regulatório brasileiro.

## Características Principais

* **FHIR R5**: Base técnica moderna
* **IDMP Completo**: Padrões internacionais de identificação
* **Compliance ANVISA**: Alinhado com regulamentações brasileiras
* **Interoperabilidade**: Compatible com padrões internacionais

## Profiles Implementados

* MedicinalProductDefinition-br
* SubstanceDefinition-br
* Organization-anvisa

## Status

Este é um protótipo funcional (v0.0.1) em desenvolvimento. Não deve ser considerado como fonte normativa.


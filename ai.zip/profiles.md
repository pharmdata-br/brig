# Profiles Brasileiros - BRIG - Guia de Implementação Brasileiro para IDMP v0.0.3

* [**Table of Contents**](toc.md)
* **Profiles Brasileiros**

## Profiles Brasileiros

| |
| :--- |
| *Page standards status:*[Informative](http://hl7.org/fhir/R5/versions.html#std-process) |

# Profiles Brasileiros

